# Student-t HMM for Bank Bond-Portfolio Regimes — Overleaf project (English)

Ready-to-compile LaTeX project. All figures carry English in-figure labels.

## How to compile on Overleaf
1. New Project -> Upload Project -> select this ZIP.
2. Menu -> Settings -> Compiler: **pdfLaTeX**.
3. Recompile.

The preamble uses `\usepackage[russian,english]{babel}` with `[T2A]{fontenc}` +
`[utf8]{inputenc}`, so it compiles as-is on Overleaf (also works with XeLaTeX/LuaLaTeX).

## Contents
- `main.tex` — the article (English), 11 figures, 12 tables.
- `figures/fig1..fig11` — publication-quality figures with English labels:
  1. Regime timeline (portfolio value + posterior)
  2. QQ tails by regime (Student-t vs Normal)
  3. Regime-conditional VaR/ES (corrected t-parametrization)
  4. Transition matrix + segment mean returns
  5. Rolling out-of-sample VaR backtest (t-HMM vs Gaussian)
  6. VaR coverage across 5 models
  7. Expected Shortfall backtest (Acerbi-Szekely)
  8. VaR decomposition by segment
  9. Bootstrap confidence intervals for regime parameters
  10. DCC-GARCH benchmark (coverage + correlation dynamics)
  11. Macro-dependent transitions + early-warning signal

## Data & methods (summary)
- Source: MOEX ISS. Macro: CBR policy rate (BIS), inflation (World Bank), USD/RUB (MOEX).
- Portfolio: 124 RUB-denominated issues, 7 segments; total return (clean price + coupon carry).
- Panel: 904 trading days (2021-07-29 to 2026-07-17).
- Model: multivariate Student-t HMM, K=4 (BIC), ECM with Gaussian warm start.

## Key results
- At 99%, the Normal approximation is rejected on both VaR (Kupiec p=0.012) and ES
  (Acerbi-Szekely p=0.043); the t-HMM is calibrated on both.
- Risk concentrates in credit segments (Corp_L3 ~28%, MBS ~24%), reallocating by regime.
- Main macro driver of stress entry is the CBR policy rate (OR=2.21, p=0.005); early-warning AUC=0.88.
